﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AppRegistroMultas.Models; 

namespace AppRegistroMultas.Contexto
{
    public static class Context
    {
        public static List<Veiculo> ListaVeiculos = new List<Veiculo> ();
        public static List<Multa> ListaMultas = new List<Multa> ();
    }
}
