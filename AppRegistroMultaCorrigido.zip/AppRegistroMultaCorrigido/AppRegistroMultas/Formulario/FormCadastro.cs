﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppRegistroMultas.Contexto;
using AppRegistroMultas.Models; 

namespace AppRegistroMultas.Formulario
{
    public partial class FormCadastro : Form
    {
        public static int Id = 1; 
        public FormCadastro()
        {
            InitializeComponent();
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            txtAno.Clear();txtMarca.Clear();txtModelo.Clear();
            txtPlaca.Clear();txtModelo.Select(); //colocar o curso no campo
        }

        private void btSalvar_Click(object sender, EventArgs e)
        {
            Veiculo veiculo = new Veiculo();
            veiculo.Modelo = txtModelo.Text;
            veiculo.Placa = txtPlaca.Text;
            veiculo.Marca = txtMarca.Text;
            veiculo.Ano = Convert.ToInt32(txtAno.Text);
            veiculo.Id = Id;
            Id++; 
            Context.ListaVeiculos.Add(veiculo); 
            MessageBox.Show("SALVO COM SUCESSO!", "2A/INF",MessageBoxButtons.OK, MessageBoxIcon.Information);
            txtAno.Clear(); txtMarca.Clear(); txtModelo.Clear();
            txtPlaca.Clear(); txtModelo.Select();
        }
    }
}
