﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppRegistroMultas.Models;
using AppRegistroMultas.Contexto; 

namespace AppRegistroMultas.Formulario
{
    public partial class FormCadastroMulta : Form
    {
        public static int idMulta=1;
        public int idVeiculo;
        List<Veiculo> listaVeiculos = new List<Veiculo>();  
        List<Multa> listaMultasTemp = new List<Multa>();//lista temporária 
        int cont = 1;
        
        public FormCadastroMulta()
        {
            InitializeComponent();
            listaVeiculos = Context.ListaVeiculos.ToList();//trazer do banco
            cbVeiculo.DataSource = listaVeiculos.ToList();
            cbVeiculo.DisplayMember = "Placa";
            cbVeiculo.SelectedIndex = -1; 
        }

        private void cbVeiculo_SelectedIndexChanged(object sender, EventArgs e)
        {
            int linhaSelec = cbVeiculo.SelectedIndex;
            if (linhaSelec > -1 && cont > 1) 
            { 
                var veiculo = listaVeiculos[linhaSelec];
                txtModelo.Text = veiculo.Modelo;
                txtMarca.Text = veiculo.Marca;
                txtPlaca.Text = veiculo.Placa;
                txtAno.Text = veiculo.Ano.ToString();
                idVeiculo = veiculo.Id;
            
            }
            cont++; 
        }

        private void btAdd_Click(object sender, EventArgs e)
        {
            Multa multa = new Multa();
            multa.Descricao = txtDescricao.Text;
            multa.Valor = Convert.ToDouble(txtValor.Text);
            multa.Id = idMulta; //Chave primária 
            multa.IdVeiculo = idVeiculo;//vinculando a multa ao veículo(chave estr) 
            listaMultasTemp.Add(multa);
            dtTabela.DataSource = listaMultasTemp.ToList();//colocar na tabela as multas
            txtDescricao.Clear();txtValor.Clear();
            txtDescricao.Select();
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            txtDescricao.Clear(); txtValor.Clear();
            txtAno.Clear(); txtMarca.Clear(); txtModelo.Clear();
            txtPlaca.Clear(); txtModelo.Select();
        }

        private void btSalvar_Click(object sender, EventArgs e)
        {
            Context.ListaMultas.AddRange(listaMultasTemp);//salvar uma lista de obj
            MessageBox.Show("SALVO COM SUCESSO!", "2A/INF", MessageBoxButtons.OK, MessageBoxIcon.Information);
            txtDescricao.Clear(); txtValor.Clear();
            txtAno.Clear(); txtMarca.Clear(); txtModelo.Clear();
            txtPlaca.Clear(); txtModelo.Select();
            listaMultasTemp.Clear();//limpar a lista temporária
            dtTabela.DataSource=listaMultasTemp.ToList();//limpar a tabela
            cbVeiculo.SelectedIndex = -1; //limpar o combobox

        }
    }
}
