﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppRegistroMultas.Models;
using AppRegistroMultas.Contexto;

namespace AppRegistroMultas.Formulario
{
    public partial class FormConsultaVeiculo : Form
    {
        List<Veiculo> listaVeiculos = new List<Veiculo>();
        List<Multa> listaMulta = new List<Multa>();
        int cont = 1; 

        public FormConsultaVeiculo()
        {
            InitializeComponent();
            listaVeiculos = Context.ListaVeiculos.ToList();
            listaMulta = Context.ListaMultas.ToList();
            cbVeiculo.DataSource = listaVeiculos.ToList();
            cbVeiculo.DisplayMember = "Placa"; 
            cbVeiculo.SelectedIndex = -1; 
        }

        private void cbVeiculo_SelectedIndexChanged(object sender, EventArgs e)
        {
            int linhaSelec = cbVeiculo.SelectedIndex;
            if (linhaSelec > -1 && cont > 1)
            {
                var veiculo = listaVeiculos[linhaSelec];
                txtModelo.Text = veiculo.Modelo;
                txtMarca.Text = veiculo.Marca;
                txtPlaca.Text = veiculo.Placa;
                txtAno.Text = veiculo.Ano.ToString();
                var multasSelec = listaMulta.Where(m=>m.IdVeiculo==veiculo.Id).ToList();
                dtTabela.DataSource = multasSelec.ToList();
            }
            cont++;
        }
    }
}
