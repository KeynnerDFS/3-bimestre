﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AppExemploPedido.Models;

namespace AppExemploPedido.Contexto
{
    public static class Contexto
    {
        public static List<Pedido> ListaPedidos = new List<Pedido>();
        public static List<Item> ListaItens = new List<Item>();
    }
}
