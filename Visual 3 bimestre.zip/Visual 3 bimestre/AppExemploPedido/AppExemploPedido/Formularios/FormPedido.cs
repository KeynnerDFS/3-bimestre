﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppExemploPedido.Models;
using AppExemploPedido.Contexto;

namespace AppExemploPedido.Formularios
{
    public partial class FormPedido : Form
    {
        public Pedido pedido = new Pedido();
        public Item Item { get; set; }
        public List<Item> itens = new List<Item>();
        static int IdPedido = 1;
        static int IdItem = 1;
        public FormPedido()
        {
            InitializeComponent();
        }

        private void btCalcular_Click(object sender, EventArgs e)
        {
            Item item = new Item();
            //item.Id = ++IdItem; Ainda não é a hora.
            item.Descricao = txtProduto.Text;
            item.Quantidade = Convert.ToDouble(txtQuantidade.Text);
            item.PrecoUni = Convert.ToDouble(txtPrecoUnit.Text);
            item.CalcularTotal();
            txtTotal.Text = item.Total.ToString("F2");
            Item = item;

        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            txtCpf.Clear(); txtNome.Clear();txtNumeroPedido.Clear();txtPrecoUnit.Clear();txtProduto.Clear();txtQuantidade.Clear();txtTotal.Clear();
            txtNumeroPedido.Select();
        }

        private void btAdd_Click(object sender, EventArgs e)
        {
            Item.Id = IdItem;//chve primaria
            Item.IdPedido = IdPedido;//chave estrangeira
            itens.Add(Item);//salva na lista local
            IdItem++;//incrementar o valordo Id do proximo registro
            dtTabela.DataSource = itens.ToList();//conecta com a tabela
            txtPrecoUnit.Clear(); txtProduto.Clear(); txtQuantidade.Clear(); txtTotal.Clear(); txtProduto.Select();
        }

        private void btSalvar_Click(object sender, EventArgs e)
        {
            pedido = new Pedido();
            pedido.Id = IdPedido;  
            pedido.NumeroPedido = Convert.ToInt32(txtNumeroPedido.Text);
            pedido.Nome = txtNome.Text;
            pedido.Cpf = txtCpf.Text;
            //com objeto pedido preenchido, vamos salvar
            Context.ListaPedidos.Add(pedido);
            Context.ListaItens.AddRange(itens);
            MessageBox.Show("Salvo com sucesso", "2ª A INF", MessageBoxButtons.OK, MessageBoxIcon.Information);
            IdPedido++;//gerar o valor do Id do proximo registro
            txtCpf.Clear(); txtNome.Clear(); txtNumeroPedido.Clear(); txtPrecoUnit.Clear(); txtProduto.Clear(); txtQuantidade.Clear(); txtTotal.Clear();
            txtNumeroPedido.Select();
            itens.Clear();//Limpar a lista
            dtTabela.DataSource = itens.ToList();//limpar tabela
        }
    }
}
