﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppExemploPedido.Models;
using AppExemploPedido.Contexto;

namespace AppExemploPedido.Formularios
{
    public partial class FormPedido : Form
    {
        public Pedido pedido = new Pedido();
        public Item Item { get; set; }
        public List<Item> itens = new List<Item>();
        static int IdPedido = 1;
        static int IdItem = 1;
        public FormPedido()
        {
            InitializeComponent();
        }

        private void btCalcular_Click(object sender, EventArgs e)
        {
            Item item = new Item();
            //item.Id = ++IdItem; Ainda não é a hora.
            item.Descricao = txtProduto.Text;
            item.Quantidade = Convert.ToDouble(txtQuantidade.Text);
            item.PrecoUni = Convert.ToDouble(txtPrecoUnit.Text);
            item.CalcularTotal();
            txtTotal.Text = item.Total.ToString("F2");
            Item = item;

        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            txtCpf.Clear(); txtNome.Clear();txtNumeroPedido.Clear();txtPrecoUnit.Clear();txtProduto.Clear();txtQuantidade.Clear();txtTotal.Clear();
            txtNumeroPedido.Select();
        }

        private void btAdd_Click(object sender, EventArgs e)
        {
            Item.Id = IdItem;
            Item.IdPedido = IdPedido;
            itens.Add(Item);
            IdItem++;
            dtTabela.DataSource = itens.ToList();
            txtPrecoUnit.Clear(); txtProduto.Clear(); txtQuantidade.Clear(); txtTotal.Clear(); txtProduto.Select();
        }
    }
}
