﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppExemploPedido.Contexto;


namespace AppExemploPedido.Formularios
{
    public partial class FormListaPedido : Form
    {
        public FormListaPedido()
        {
            InitializeComponent();
            var listaPedido = Context.ListaPedidos.ToList();
            dtTabela.DataSource = listaPedido.ToList();
        }
    }
}
