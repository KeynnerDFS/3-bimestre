﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppExemploPedido.Formularios;

namespace AppExemploPedido
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btCadastrarPedido_Click(object sender, EventArgs e)
        {
            FormPedido form = new FormPedido();
            form.ShowDialog();
        }

        private void btListarPedidos_Click(object sender, EventArgs e)
        {
            FormListaPedido form = new FormListaPedido();
            form.ShowDialog();
        }

        private void btListarItens_Click(object sender, EventArgs e)
        {
            FormItens form = new FormItens();
            form.ShowDialog();
        }

        private void btCosnultarPedidos_Click(object sender, EventArgs e)
        {
            FormConsultaPedido form = new FormConsultaPedido(); 
            form.ShowDialog();
        }
    }
}
