﻿namespace AppFormsExemplo2
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btSoma = new System.Windows.Forms.Button();
            this.btMultiplicacao = new System.Windows.Forms.Button();
            this.btDivisao = new System.Windows.Forms.Button();
            this.btVolumeCubico = new System.Windows.Forms.Button();
            this.btAreaRetangular = new System.Windows.Forms.Button();
            this.btPotencia = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btSoma
            // 
            this.btSoma.BackColor = System.Drawing.Color.Yellow;
            this.btSoma.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSoma.Location = new System.Drawing.Point(11, 56);
            this.btSoma.Name = "btSoma";
            this.btSoma.Size = new System.Drawing.Size(667, 40);
            this.btSoma.TabIndex = 0;
            this.btSoma.Text = "CALCULAR SOMA";
            this.btSoma.UseVisualStyleBackColor = false;
            this.btSoma.Click += new System.EventHandler(this.btSoma_Click);
            // 
            // btMultiplicacao
            // 
            this.btMultiplicacao.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btMultiplicacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btMultiplicacao.Location = new System.Drawing.Point(11, 102);
            this.btMultiplicacao.Name = "btMultiplicacao";
            this.btMultiplicacao.Size = new System.Drawing.Size(667, 40);
            this.btMultiplicacao.TabIndex = 1;
            this.btMultiplicacao.Text = "CALCULAR MULTIPLICAÇÃO\r\n";
            this.btMultiplicacao.UseVisualStyleBackColor = false;
            this.btMultiplicacao.Click += new System.EventHandler(this.btMultiplicacao_Click);
            // 
            // btDivisao
            // 
            this.btDivisao.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btDivisao.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btDivisao.Location = new System.Drawing.Point(11, 148);
            this.btDivisao.Name = "btDivisao";
            this.btDivisao.Size = new System.Drawing.Size(667, 33);
            this.btDivisao.TabIndex = 2;
            this.btDivisao.Text = "CALCULAR DIVISÃO";
            this.btDivisao.UseVisualStyleBackColor = false;
            this.btDivisao.Click += new System.EventHandler(this.btDivisao_Click);
            // 
            // btVolumeCubico
            // 
            this.btVolumeCubico.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btVolumeCubico.Location = new System.Drawing.Point(11, 187);
            this.btVolumeCubico.Name = "btVolumeCubico";
            this.btVolumeCubico.Size = new System.Drawing.Size(667, 31);
            this.btVolumeCubico.TabIndex = 3;
            this.btVolumeCubico.Text = "CALCULAR VOLUME CUBICO";
            this.btVolumeCubico.UseVisualStyleBackColor = true;
            this.btVolumeCubico.Click += new System.EventHandler(this.btVolumeCubico_Click);
            // 
            // btAreaRetangular
            // 
            this.btAreaRetangular.BackColor = System.Drawing.Color.Violet;
            this.btAreaRetangular.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btAreaRetangular.Location = new System.Drawing.Point(11, 224);
            this.btAreaRetangular.Name = "btAreaRetangular";
            this.btAreaRetangular.Size = new System.Drawing.Size(667, 30);
            this.btAreaRetangular.TabIndex = 4;
            this.btAreaRetangular.Text = "CALCULAR AREA RETANGULAR";
            this.btAreaRetangular.UseVisualStyleBackColor = false;
            this.btAreaRetangular.Click += new System.EventHandler(this.btAreaRetangular_Click);
            // 
            // btPotencia
            // 
            this.btPotencia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btPotencia.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btPotencia.Location = new System.Drawing.Point(9, 260);
            this.btPotencia.Name = "btPotencia";
            this.btPotencia.Size = new System.Drawing.Size(667, 30);
            this.btPotencia.TabIndex = 5;
            this.btPotencia.Text = "CALCULAR POTENCIA";
            this.btPotencia.UseVisualStyleBackColor = false;
            this.btPotencia.Click += new System.EventHandler(this.btPotencia_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(688, 450);
            this.Controls.Add(this.btPotencia);
            this.Controls.Add(this.btAreaRetangular);
            this.Controls.Add(this.btVolumeCubico);
            this.Controls.Add(this.btDivisao);
            this.Controls.Add(this.btMultiplicacao);
            this.Controls.Add(this.btSoma);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btSoma;
        private System.Windows.Forms.Button btMultiplicacao;
        private System.Windows.Forms.Button btDivisao;
        private System.Windows.Forms.Button btVolumeCubico;
        private System.Windows.Forms.Button btAreaRetangular;
        private System.Windows.Forms.Button btPotencia;
    }
}

