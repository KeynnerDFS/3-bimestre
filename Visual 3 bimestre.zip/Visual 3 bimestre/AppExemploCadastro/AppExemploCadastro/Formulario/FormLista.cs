﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppExemploCadastro.Models;
using AppExemploCadastro.Contexto;

namespace AppExemploCadastro.Formulario
{
    public partial class FormLista : Form
    {
        public FormLista()
        {
            InitializeComponent();
            var listaPessoas = Context.ListPessoa.ToList();
            dtTabela.DataSource = listaPessoas.ToList();//Coloca os dados no grid
        }

        private void dtTabela_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
