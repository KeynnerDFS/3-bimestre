﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppExemploCadastro.Models; //acesso a classe pessoa
using AppExemploCadastro.Contexto; // ter acesso a classe dos dados (Context)


namespace AppExemploCadastro.Formulario
{
    public partial class FormCadastro : Form
    {
        public FormCadastro()
        {
            InitializeComponent();
        }

        private void btSalvar_Click(object sender, EventArgs e)
        {
            Pessoa pessoa = new Pessoa();
            pessoa.Nome = txtNome.Text;
            pessoa.Cpf = txtCpf.Text;
            pessoa.RegistroGeral = txtRegistroGeral.Text;
            pessoa.Email = txtEmail.Text;
            pessoa.Id = Context.ListPessoa.Count + 1;
            Context.ListPessoa.Add(pessoa);
            MessageBox.Show("Salvo com sucesso!", "2°A INF", MessageBoxButtons.OK, MessageBoxIcon.Information);
            txtNome.Clear(); txtCpf.Clear(); txtEmail.Clear(); txtRegistroGeral.Clear();
            txtNome.Select();

        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            txtNome.Clear(); txtCpf.Clear(); txtEmail.Clear(); txtRegistroGeral.Clear();
            txtNome.Select();
        }
    }
}
