﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppRegistroMultas.Formulario;
using AppRegistroMultas.Models;
using AppRegistroMultas.Contexto;

namespace AppRegistroMultas.Formulario
{
    public partial class FormCadastro : Form
    {
        public Veiculo veiculo = new Veiculo();
       
        static int IdVeiculo = 1;
        static int IdMulta = 1;
        public FormCadastro()
        {
            InitializeComponent();
        }

        private void btSalvar_Click(object sender, EventArgs e)
        {
            veiculo = new Veiculo();
            veiculo.Id = IdVeiculo;
            veiculo.Ano = Convert.ToInt32(txtAno.Text);
            veiculo.Marca = txtMarca.Text;
            veiculo.Modelo = txtModelo.Text;
            veiculo.Placa = txtPlaca.Text;
            //com objeto pedido preenchido, vamos salvar
            Context.ListaVeiculos.Add(veiculo);
            MessageBox.Show("Salvo com sucesso", "2ª A INF", MessageBoxButtons.OK, MessageBoxIcon.Information);
            IdVeiculo++;//gerar o valor do Id do proximo registro
            txtPlaca.Clear(); txtModelo.Clear(); txtMarca.Clear(); txtAno.Clear(); txtModelo.Select();
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            txtPlaca.Clear(); txtModelo.Clear(); txtMarca.Clear(); txtAno.Clear(); txtModelo.Select();
        }
    }
}
