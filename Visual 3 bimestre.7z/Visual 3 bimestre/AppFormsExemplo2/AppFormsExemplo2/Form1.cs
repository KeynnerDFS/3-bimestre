﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppFormsExemplo2.Formularios;

namespace AppFormsExemplo2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btSoma_Click(object sender, EventArgs e)
        {
            FormSoma form = new FormSoma();
            form.ShowDialog();//chamar o form soma
        }

        private void btMultiplicacao_Click(object sender, EventArgs e)
        {
            FormMultiplicacao form = new FormMultiplicacao();
            form.ShowDialog();//chamar o form multiplicação
        }

        private void btDivisao_Click(object sender, EventArgs e)
        {
            FormDivisao form = new FormDivisao();
            form.ShowDialog();//chamar o form Divisão
        }

        private void btVolumeCubico_Click(object sender, EventArgs e)
        {
            FormCalcularVolumeCubico form = new FormCalcularVolumeCubico();
            form.ShowDialog();//chamar o form Volume cubico
        }

        private void btAreaRetangular_Click(object sender, EventArgs e)
        {
            FormAreaRetangular form = new FormAreaRetangular();
            form.ShowDialog();//chamar o form area retangular
        }

        private void btPotencia_Click(object sender, EventArgs e)
        {
            FormPotencia form = new FormPotencia();
            form.ShowDialog();//chamar o form potencia
        }
    }
}
