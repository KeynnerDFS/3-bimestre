﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppRegistroMultas.Formulario;
using AppRegistroMultas.Contexto;
using AppRegistroMultas.Models;

namespace AppRegistroMultas.Formulario
{
    public partial class FormConsultaVeiculo : Form
    {
        public List<Veiculo> veiculo = new List<Veiculo>();
        public List<Multa> multas = new List<Multa>();
        int cont = 1;

        public FormConsultaVeiculo()
        {
            InitializeComponent();
            veiculo = Context.ListaVeiculos.ToList();
            multas = Context.ListaMultas.ToList();
            cbVeiculo.DataSource = veiculo.ToList();
            cbVeiculo.DisplayMember = "Placa";
            cbVeiculo.SelectedIndex = -1;
        }

        private void cbVeiculo_SelectedIndexChanged(object sender, EventArgs e)
        {
            int linhaSelec = cbVeiculo.SelectedIndex;
            if (linhaSelec > -1 && cont > 1)
            {
                var veiculos = veiculo[linhaSelec];
                txtModelo.Text = veiculos.Modelo;
                txtMarca.Text = veiculos.Marca;
                txtPlaca.Text = veiculos.Placa;
                txtAno.Text = veiculos.Ano.ToString();
                //master detalhe
                var multasDetalhe = multas.Where(i => i.IdVeiculo == veiculos.Id).ToList();
                dtTabela.DataSource = multasDetalhe.ToList();
                var total = multasDetalhe.Sum(i => i.Valor);
                txtTotal.Text = total.ToString();


            }
            cont++;
        }
    }
}
