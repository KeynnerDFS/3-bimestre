﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppRegistroMultas.Formulario;
using AppRegistroMultas.Contexto;
using AppRegistroMultas.Models;

namespace AppRegistroMultas.Formulario
{
    public partial class FormCadastroMulta : Form
    {
        public List<Veiculo> veiculo = new List<Veiculo>();
        public Veiculo veiculos = new Veiculo();
       
        public Multa multa { get; set; }
        public List<Multa> multas = new List<Multa>();
        static int IdVeiculo = 1;
        static int IdMulta = 1;
        int cont = 1;
  
        public FormCadastroMulta()
        {
            InitializeComponent();
            veiculo = Context.ListaVeiculos.ToList();
            multas = Context.ListaMultas.ToList();
            cbVeiculo.DataSource = veiculo.ToList();
            cbVeiculo.DisplayMember = "Modelo";
            cbVeiculo.SelectedIndex = -1;
        }

       
        private void cbVeiculo_SelectedIndexChanged(object sender, EventArgs e)
        {
            int linhaSelec = cbVeiculo.SelectedIndex;
            if (linhaSelec > -1 && cont > 1)
            {
                var veiculos = veiculo[linhaSelec];
                txtModelo.Text = veiculos.Modelo;
                txtMarca.Text = veiculos.Marca;
                txtPlaca.Text = veiculos.Placa;
                txtAno.Text = veiculos.Ano.ToString();
                //master detalhe
                
            }
            cont++;
        }

        private void btAdd_Click(object sender, EventArgs e)
        {
            Multa multa = new Multa();
            //item.Id = ++IdItem; Ainda não é a hora.
            multa.Descricao = txtDescricao.Text;
            multa.Valor = Convert.ToDouble(txtValor.Text);
            multa.Id = IdMulta;//chve primaria
            multa.IdVeiculo = IdVeiculo;//chave estrangeira
            multas.Add(multa);//salva na lista local
            IdMulta++;//incrementar o valordo Id do proximo registro
            dtTabela.DataSource = multas.ToList();//conecta com a tabela
            txtDescricao.Clear(); txtValor.Clear(); txtDescricao.Select();
        }

        private void btSalvar_Click(object sender, EventArgs e)
        {

            veiculos.Id = IdVeiculo;
            veiculos.Ano = Convert.ToInt32(txtAno.Text);
            veiculos.Marca = txtMarca.Text;
            veiculos.Modelo = txtModelo.Text;
            veiculos.Placa = txtPlaca.Text;
            //com objeto pedido preenchido, vamos salvar
            Context.ListaVeiculos.Add(veiculos);
            Context.ListaMultas.AddRange(multas);
            MessageBox.Show("Salvo com sucesso", "2ª A INF", MessageBoxButtons.OK, MessageBoxIcon.Information);
            IdVeiculo++;
            txtPlaca.Clear(); txtModelo.Clear(); txtMarca.Clear(); txtAno.Clear(); txtModelo.Select(); txtDescricao.Clear(); txtValor.Clear();
            multas.Clear();//Limpar a lista
            dtTabela.DataSource = multas.ToList();//limpar tabela
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            txtDescricao.Clear(); txtValor.Clear();//Cancela a multa que estava sendo Digitada
        }
    }
}
